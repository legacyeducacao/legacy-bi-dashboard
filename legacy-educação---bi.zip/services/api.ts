
import { MetricData, RepPerformance, PeriodContext, FunnelStage, MarketingChannelStats, MarketingProductStats } from '../types';
import { KPI_METRICS, DAILY_TRENDS, SDR_DATA, CLOSER_DATA, MARKETING_CHANNELS_DATA, MARKETING_PRODUCTS_DATA, MOCK_CONTEXT, FUNNEL_DATA } from './mockData';

// Link fixo do Web App do Google Apps Script (Atualizado)
const API_URL = 'https://script.google.com/macros/s/AKfycbzdcVpzBL3HTPmAjUYJGjU-XN6RW1XaccQC1szEf89d3jn4Hx7Va7vhQTvmQsqkdnXVjw/exec';

export interface DashboardData {
  kpis: Record<string, MetricData>;
  dailyTrends: any[];
  sdrData: RepPerformance[];
  closerData: RepPerformance[];
  channels: MarketingChannelStats[];
  products: MarketingProductStats[];
  context: PeriodContext;
  funnelData: FunnelStage[];
  lastUpdated: Date;
}

// Helper para buscar valor em chaves variadas (Case insensitive / variações)
const getProp = (obj: any, keys: string[]) => {
  if (!obj) return undefined;
  for (const key of keys) {
    if (obj[key] !== undefined && obj[key] !== "") return obj[key];
  }
  return undefined;
};

export const fetchDashboardData = async (): Promise<DashboardData> => {
  try {
    // Adiciona timestamp para evitar cache do navegador/proxy
    const noCacheUrl = `${API_URL}?t=${new Date().getTime()}`;
    
    const response = await fetch(noCacheUrl, {
      method: 'GET',
      mode: 'cors', // Garante que tente usar CORS
      redirect: 'follow' // Segue os redirects do Google (302)
    });

    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
    }
    
    const json = await response.json();
    console.log("Dados recebidos da API:", json); // Debug no console
    
    // --- 1. Transform KPIs ---
    const kpis: Record<string, MetricData> = {};
    const kpiSheet = json.KPIs_Principais || json['KPIs_Principais'];
    
    if (kpiSheet && Array.isArray(kpiSheet)) {
       kpiSheet.forEach((row: any) => {
          const id = getProp(row, ['ID', 'id']);
          if (id) {
            kpis[id] = {
              id: id,
              label: getProp(row, ['Nome da Métrica', 'Nome', 'Metrica', 'label']) || 'Métrica',
              value: Number(getProp(row, ['Valor Atual', 'Valor', 'value']) || 0),
              goal: Number(getProp(row, ['Meta Mensal', 'Meta', 'goal']) || 0),
              unit: getProp(row, ['Unidade', 'unit']) || 'number',
              prefix: getProp(row, ['Prefixo', 'prefix']) || '',
              suffix: getProp(row, ['Sufixo', 'suffix']) || ''
            };
          }
       });
    }

    // Mesclar com KPIs padrão para evitar quebras se a planilha estiver incompleta
    const mergedKpis = { ...KPI_METRICS, ...kpis };

    // --- 2. Transform Context ---
    let context = { ...MOCK_CONTEXT };
    const configSheet = json.Configuracoes_Gerais || json['Configuracoes_Gerais'];
    
    if (configSheet && Array.isArray(configSheet)) {
       const curDayRow = configSheet.find((r:any) => {
          const conf = getProp(r, ['Configuração', 'Configuracao', 'config']);
          return conf === 'Dia Atual do Mês';
       });
       const totDayRow = configSheet.find((r:any) => {
          const conf = getProp(r, ['Configuração', 'Configuracao', 'config']);
          return conf === 'Total Dias do Mês';
       });

       if(curDayRow) context.currentDay = Number(getProp(curDayRow, ['Valor', 'valor']) || MOCK_CONTEXT.currentDay);
       if(totDayRow) context.totalDays = Number(getProp(totDayRow, ['Valor', 'valor']) || MOCK_CONTEXT.totalDays);
    }

    // --- 3. Transform Trends ---
    let dailyTrends = DAILY_TRENDS;
    const trendsSheet = json.Tendencia_Diaria || json['Tendencia_Diaria'];
    
    if (trendsSheet && Array.isArray(trendsSheet)) {
       dailyTrends = trendsSheet.map((row: any, idx: number) => ({
          day: getProp(row, ['Dia', 'day']) || `Dia ${idx + 1}`,
          dayIndex: idx + 1,
          leads: Number(getProp(row, ['Leads', 'leads']) || 0),
          mqls: Number(getProp(row, ['MQLs', 'mqls']) || 0),
          investment: Number(getProp(row, ['Investimento (R$)', 'Investimento', 'invest']) || 0),
          revenue: Number(getProp(row, ['Faturamento (R$)', 'Faturamento', 'revenue', 'Receita']) || 0),
          sales: Number(getProp(row, ['Vendas', 'sales']) || 0),
          activities: Number(getProp(row, ['Atividades', 'activities']) || 0),
          connected: Number(getProp(row, ['Conexões', 'Conexoes', 'connected']) || 0)
       }));
    }

    // --- 4. Transform SDR ---
    let sdrData = SDR_DATA;
    const sdrSheet = json.Time_SDR || json['Time_SDR'];
    
    if (sdrSheet && Array.isArray(sdrSheet)) {
       sdrData = sdrSheet.map((row: any) => ({
          id: String(getProp(row, ['ID', 'id'])),
          name: getProp(row, ['Nome', 'nome', 'name']),
          role: 'SDR',
          opportunities: Number(getProp(row, ['Oportunidades', 'opportunities']) || 0),
          connections: Number(getProp(row, ['Conexões', 'Conexoes', 'connections']) || 0),
          meetingsBooked: Number(getProp(row, ['Reuniões Agendadas', 'meetingsBooked']) || 0),
          meetingsHeld: Number(getProp(row, ['Reuniões Realizadas', 'meetingsHeld']) || 0),
          noShowCount: Number(getProp(row, ['No Show', 'noShow']) || 0),
          responseTime: Number(getProp(row, ['Tempo Resp (min)', 'responseTime']) || 0)
       }));
    }

    // --- 5. Transform Closers ---
    let closerData = CLOSER_DATA;
    const closerSheet = json.Time_Closers || json['Time_Closers'];
    
    if (closerSheet && Array.isArray(closerSheet)) {
      closerData = closerSheet.map((row: any) => ({
         id: String(getProp(row, ['ID', 'id'])),
         name: getProp(row, ['Nome', 'nome', 'name']),
         role: 'Closer',
         meetingsHeld: Number(getProp(row, ['Reuniões Realizadas', 'meetingsHeld']) || 0),
         sales: Number(getProp(row, ['Vendas', 'sales']) || 0),
         revenue: Number(getProp(row, ['Faturamento Gerado', 'revenue']) || 0),
         noShowCount: Number(getProp(row, ['No Show Count', 'noShowCount']) || 0),
         meetingsBooked: Number(getProp(row, ['Reuniões Agendadas', 'meetingsBooked']) || 0)
      }));
    }

    // --- 6. Channels ---
    let channels = MARKETING_CHANNELS_DATA;
    const channelSheet = json.Canais_Marketing || json['Canais_Marketing'];
    
    if (channelSheet && Array.isArray(channelSheet)) {
       channels = channelSheet.map((row: any) => ({
          channel: getProp(row, ['Canal', 'channel']),
          investment: Number(getProp(row, ['Investimento', 'investment']) || 0),
          leads: Number(getProp(row, ['Leads', 'leads']) || 0),
          cpl: Number(getProp(row, ['CPL', 'cpl']) || 0),
          mqls: Number(getProp(row, ['MQLs', 'mqls']) || 0),
          sales: Number(getProp(row, ['Vendas', 'sales']) || 0),
          revenue: Number(getProp(row, ['Receita', 'revenue']) || 0),
          roas: Number(getProp(row, ['ROAS', 'roas']) || 0)
       }));
    }

    // --- 7. Products ---
    let products = MARKETING_PRODUCTS_DATA;
    const productSheet = json.Produtos || json['Produtos'];

    if (productSheet && Array.isArray(productSheet)) {
       products = productSheet.map((row: any) => ({
          product: getProp(row, ['Produto', 'product']),
          investment: Number(getProp(row, ['Investimento', 'investment']) || 0),
          leads: Number(getProp(row, ['Leads', 'leads']) || 0),
          cpl: Number(getProp(row, ['CPL', 'cpl']) || 0),
          sales: Number(getProp(row, ['Vendas', 'sales']) || 0),
          revenue: Number(getProp(row, ['Receita', 'revenue']) || 0),
          roas: Number(getProp(row, ['ROAS', 'roas']) || 0)
       }));
    }

    // --- 8. Construct Funnel ---
    const funnelData = [
       { name: 'Leads', value: mergedKpis.leads?.value || 0 },
       { name: 'Oportunidades', value: mergedKpis.opps?.value || 0 },
       { name: 'Conexões', value: mergedKpis.connections?.value || 0 },
       { name: 'Agendadas', value: mergedKpis.meetings_booked?.value || 0 },
       { name: 'Realizadas', value: mergedKpis.meetings_held?.value || 0 },
       { name: 'Vendas', value: mergedKpis.sales?.value || 0 },
    ];

    return {
       kpis: mergedKpis,
       dailyTrends,
       sdrData,
       closerData,
       channels,
       products,
       context,
       funnelData,
       lastUpdated: new Date()
    };

  } catch (error) {
    console.warn("API Error, using fallback data. Details:", error);
    // Return mock data on failure to keep app usable, but warn in console
    return {
       kpis: KPI_METRICS,
       dailyTrends: DAILY_TRENDS,
       sdrData: SDR_DATA,
       closerData: CLOSER_DATA,
       channels: MARKETING_CHANNELS_DATA,
       products: MARKETING_PRODUCTS_DATA,
       context: MOCK_CONTEXT,
       funnelData: FUNNEL_DATA,
       lastUpdated: new Date()
    };
  }
};
